import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Gasto = {
  id: string
  nome: string
  tipo: 'parcelado' | 'recorrente'
  valor: number
  vencimento_dia: number
  // parcelado
  parcelas_total?: number
  mes_inicio?: string // 'YYYY-MM'
  // recorrente
  ativo: boolean
  created_at: string
}
